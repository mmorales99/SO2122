{ Constant definitions for jBACI graphics. }
const
	RED = 1; BLACK = 2; BLUE = 3; YELLOW = 4; GREEN = 5; MAGENTA = 6; WHITE = 7;
	CIRCLE = 1; LINE = 2; RECTANGLE = 3; TRIANGLE = 4; ANIMAGE = 5;

